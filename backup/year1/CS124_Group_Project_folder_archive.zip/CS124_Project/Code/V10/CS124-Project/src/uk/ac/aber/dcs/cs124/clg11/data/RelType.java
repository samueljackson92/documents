package uk.ac.aber.dcs.cs124.clg11.data;

public enum RelType {
	COMPOSITION,
	INHERITANCE,
	AGGREGATION,
	ASSOCIATION,
}
