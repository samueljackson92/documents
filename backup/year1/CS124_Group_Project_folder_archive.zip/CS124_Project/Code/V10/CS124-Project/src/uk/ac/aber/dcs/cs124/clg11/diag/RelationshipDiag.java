package uk.ac.aber.dcs.cs124.clg11.diag;
import java.awt.Graphics;



public class RelationshipDiag extends Drawable {
	
	public RelationshipDiag() {
		//code for constructing a new relationship goes here
	}
	
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
	}

}
