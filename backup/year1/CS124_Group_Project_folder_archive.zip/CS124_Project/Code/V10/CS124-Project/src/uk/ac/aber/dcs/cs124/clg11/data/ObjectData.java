package uk.ac.aber.dcs.cs124.clg11.data;

public interface ObjectData {};
