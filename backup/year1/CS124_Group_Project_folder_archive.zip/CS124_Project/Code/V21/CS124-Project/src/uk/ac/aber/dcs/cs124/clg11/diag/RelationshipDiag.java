package uk.ac.aber.dcs.cs124.clg11.diag;

import java.awt.Graphics;
import uk.ac.aber.dcs.cs124.clg11.data.ClassDiagData;
import uk.ac.aber.dcs.cs124.clg11.data.RelationshipDiagData;
import uk.ac.aber.dcs.cs124.clg11.data.RelType;


public class RelationshipDiag extends Drawable {

	private ClassDiag a, b;
	private String assocVar;
	private String classAMulti;
	private String classBMulti;
	private String relType;
	private int diamondX, diamondY;
	private String arrowDir;


	public RelationshipDiag(ClassDiag a,ClassDiag b, String assocVar, String classAMulti, String classBMulti, String relType) {
		//code for constructing a new relationship goes here
		this.assocVar = assocVar;
		this.classAMulti = classAMulti;
		this.classBMulti = classBMulti;
		this.relType = relType;

		this.a = a;
		ClassDiagData d = (ClassDiagData) this.a.getData();
		d.addAssocInstanceVar(assocVar);

		this.b = b;
	}

	@Override
	public void paint(Graphics g) {
		//Draw relationship line with diamond at the end

		int x1 = a.getX(), y1 = a.getY(), x2 = b.getX(), y2 = b.getY();
		int w1 = 180, h1 = a.getHeight(), w2 = 180, h2 = b.getHeight(); //change 180 to getWidth
		int acx = x1+w1/2, acy = y1+h1/2, bcx = x2+w2/2, bcy = y2+h2/2;

		if (Math.abs(acx-bcx) > Math.abs(acy-bcy)) {
			if (bcy < y1) {
				g.drawLine(acx, y1, acx, bcy);
				if(x2 > x1) {
					System.out.println("side 1");
					this.diamondX = x2 - 20; //2nd class bottom right
					this.diamondY = bcy - 10;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(acx, bcy, x2 - 20, bcy);
					} else {
						g.drawLine(acx, bcy, x2, bcy);
						arrowDir = "EAST";
					}
					g.drawString(classBMulti, x2 - 40, bcy + 15); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, acx + 10, y1 - 15);
				} else {
					System.out.println("side 2");
					this.diamondX = x2 + w2; //2nd class, top left
					this.diamondY = bcy - 10;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(acx, bcy, x2 + w2 + 20, bcy); 
					} else {
						g.drawLine(acx, bcy, x2 + w2, bcy); 
						arrowDir = "WEST";
					}
					g.drawString(classBMulti, x2 + 200, bcy + 20); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, acx + 10, y1 - 15);
				}

			} else if (bcy > y1 && bcy < y1 + h1) {
				if(x2 > x1) {
					System.out.println("side 3");
					this.diamondX = x2 - 20; //2nd class left
					this.diamondY = bcy - 10;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(x1 + w1, bcy, x2 - 20, bcy);
					} else {
						g.drawLine(x1 + w1, bcy, x2, bcy);
						arrowDir = "EAST";
					}
					g.drawString(classBMulti, x2 - 40, bcy + 15); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, x1 + 190, bcy + 15);
				} else {
					System.out.println("side 4");
					this.diamondX = x2 + w2; //2nd class right
					this.diamondY = bcy - 10;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(x1, bcy, x2 + w2 + 20, bcy);
					} else {
						g.drawLine(x1, bcy, x2 + w2, bcy);
						arrowDir = "WEST";
					}
					g.drawString(classBMulti, x2 + 200, bcy + 20); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, x1 - 30, bcy + 20);
				}
			} else if (bcy > y1 + h1) {
				g.drawLine(acx, y1 + h1, acx, bcy);
				if(x2 > x1) {
					System.out.println("side 5");
					this.diamondX = x2 - 20; //2nd class top right
					this.diamondY = bcy - 10;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(acx, bcy, x2 - 20, bcy);
					} else {
						g.drawLine(acx, bcy, x2, bcy);
						arrowDir = "EAST";
					}
					g.drawString(classBMulti, x2 - 40, bcy + 15); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, acx + 10, y1 + 140);
				} else {
					System.out.println("side 6");
					this.diamondX = x2 + w2; //2nd class bottom left
					this.diamondY = bcy - 10;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(acx, bcy, x2 + w2 + 20, bcy);
					} else {
						g.drawLine(acx, bcy, x2 + w2, bcy);
						arrowDir = "WEST";
					}
					g.drawString(classBMulti, x2 + 200, bcy + 20); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, acx + 10, y1 + 140);
				}
			}

		} else {
			if (bcx < x1) {
				g.drawLine(x1, acy, bcx, acy);
				if(y2 > y1) {
					System.out.println("side 7");
					this.diamondX = bcx - 10;
					this.diamondY = y2 - 20;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(bcx, acy, bcx, y2 - 20);
					} else {
						g.drawLine(bcx, acy, bcx, y2);
						arrowDir = "SOUTH";
					}
					g.drawString(classBMulti, x2 + 100, bcy - 90); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, acx - 120, y1 + 80);
				} else {
					System.out.println("side 8");
					this.diamondX = bcx - 10;
					this.diamondY = y2 + h2;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(bcx, acy, bcx, y2 + h2 + 20); 
					} else {
						g.drawLine(bcx, acy, bcx, y2 + h2);
						arrowDir = "NORTH";
					}
					g.drawString(classBMulti, x2 + 100, bcy + 100); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, x1 - 30, y1 + 50);
				}

			} else if (bcx > x1 && bcx < x1 + w1) {
				if(y2 > y1) {
					System.out.println("side 9");
					this.diamondX = bcx - 10; //2nd class down
					this.diamondY = y2 - 20;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(bcx, y1 + h1, bcx, y2 - 20);
					} else {
						g.drawLine(bcx, y1 + h1, bcx, y2);
						arrowDir = "SOUTH";
					}
					g.drawString(classBMulti, bcx + 10, y2 - 20); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, x2 + 100, y1 + 150);
				} else {
					System.out.println("side 10");
					this.diamondX = bcx - 10;
					this.diamondY = y2 + h2;
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(bcx, y1, bcx, y2 + h2 + 20);
					} else {
						g.drawLine(bcx, y1, bcx, y2 + h2);
						arrowDir = "NORTH";
					}
					g.drawString(classBMulti, x2 + 100, bcy + 95); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, x2 + 100, y1 - 10);
				}
			} else if (bcx > x1 + w1) {
				g.drawLine(x1+ w1, acy, bcx, acy);
				if(y2 > y1) {
					this.diamondX = bcx - 10;
					this.diamondY = y2 - 20;
					System.out.println("side 11");
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(bcx, acy, bcx, y2 - 20);
					} else {
						g.drawLine(bcx, acy, bcx, y2);
						arrowDir = "SOUTH";
					}
					g.drawString(classBMulti, bcx + 10, y2 - 25); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, acx + 100, y1 + 50);
				} else {
					this.diamondX = bcx - 10;
					this.diamondY = y2 + h2;
					System.out.println("side 12");
					if (relType.equals("COMPOSITION") || relType.equals("AGGREGATION")) {
						g.drawLine(bcx, acy, bcx, y2 + h2 + 20); 
					} else {
						g.drawLine(bcx, acy, bcx, y2 + h2); 
						arrowDir = "NORTH";
					}
					g.drawString(classBMulti, x2 + 105, bcy + 85); //DRAW MULTIPLICITIES
					g.drawString(classAMulti, acx + 105, y1 + 80);
				}
			}
		}

		//code for rel types
		RelationshipDiagData d = (RelationshipDiagData) getData();

		x1 = this.diamondX;
		x2 = this.diamondX + 20;
		y1 = this.diamondY;
		y2 = this.diamondY + 20;

		int startx = (x1+x2)/2;  
		int starty = (y1+y2)/2;  

		switch (relType) {
		case "COMPOSITION":

			g.drawLine(x1, starty , startx , y1);  
			g.drawLine(startx , y1, x2, starty );  
			g.drawLine(x2, starty , startx , y2);  
			g.drawLine(startx , y2, x1, starty ); 

			break;
		case "INHERITANCE":

			switch (arrowDir) {
			case "NORTH":

				g.drawLine(startx , y1, x2, starty ); 
				g.drawLine(x1, starty , startx , y1);  

				break;
			case "SOUTH":

				g.drawLine(x2, starty , startx , y2);  
				g.drawLine(startx , y2, x1, starty ); 

				break;
			case "EAST":

				g.drawLine(startx , y1, x2, starty );  
				g.drawLine(x2, starty , startx , y2);  

				break;
			case "WEST":

				g.drawLine(x1, starty , startx , y1);
				g.drawLine(startx , y2, x1, starty ); 

				break;
			}

			break;
		case "AGGREGATION":

			int [] xpoints = { x1, startx, x2, startx, x1 };
			int [] ypoints = { starty, y1, starty, y2, starty };
			g.fillPolygon(xpoints, ypoints, xpoints.length);

			break;
		case "ASSOCIATION":
			break;
		}

	}

}
