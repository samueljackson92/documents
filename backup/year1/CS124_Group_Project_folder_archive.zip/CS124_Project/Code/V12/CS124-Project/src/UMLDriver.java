import uk.ac.aber.dcs.cs124.clg11.frame.UMLFrame;

public class UMLDriver {
	public static void main(String[] args) {
		UMLFrame umlFrame = new UMLFrame();
		umlFrame.showIt();
	}
}
