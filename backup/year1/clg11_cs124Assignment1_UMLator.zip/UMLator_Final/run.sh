cd build
java UMLDriver