/*
 * Author: Samuel Jackson
 * Description:
 * Create an instance of the cross the square game and run it.
 */

public class RunGame {
    
    public static void main(String[] args) {
        //create an instance of the game
        Menu menu = new Menu();
        //run the game
        menu.showMenu();
    }
}
