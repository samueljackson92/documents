package uk.ac.aber.dcs.cs12420.roladex.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.roladex.Contact;
import uk.ac.aber.dcs.cs12420.roladex.Roladex;


public class RoladexTest {
	
	private Contact contact;
	private Roladex roladex;
	
	@Before
	public void initTest() {
		roladex = new Roladex();
		contact = new Contact();
	}
	
	@Test
	public void testAddOneContactAndFind(){
		contact = new Contact("Samuel Jackson","012793");
		roladex.add(contact);
		
		Contact searchContact = new Contact();
		searchContact.setName("Samuel Jackson");
		
		Contact foundContact = roladex.find(searchContact);
		assertEquals("Should be equal", contact, foundContact);
	}
	
	@Test
	public void testFindNonExistentContact(){
		roladex.add(contact);
		
		Contact searchContact = new Contact();
		searchContact.setName("Samuel Jackson");
		
		Contact foundContact = roladex.find(searchContact);
		assertEquals("Should be equal", null, foundContact);
	}
}
