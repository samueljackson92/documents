package uk.ac.aber.dcs.cs12420.roladex.test;

import static org.junit.Assert.*;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.roladex.Contact;


public class ContactTest {
	@Test
	public void testCreateContactWithoutName() {
		Contact contact = new Contact();
		assertEquals("Expected an 'unknown' name",
						"unknown", contact.getName());
		assertNull("Expected phone number to be null", contact.getPhone());
	}
	
	@Test
	public void testGetPhone() {
		Contact contact = new Contact();
		assertNull("Expected phone number to be null", contact.getPhone());
	}
	
	@Test
	public void testSetPhone() {
		Contact contact = new Contact();
		contact.setPhone("017");
		assertEquals("Expected phone number to be 017",
						"017", contact.getPhone());
	}
	
	@Test
	public void testToStringWithEmptyConstructor() {
		Contact contact = new Contact();
		assertEquals("Incorrect string returned", "unknown null",
				contact.toString());
	}
	@Test
	public void testToStringWithNameAndPhoneConstructor() {
		Contact contact = new Contact("Jess", "789902");
		assertEquals("Incorrect string returned", "Jess 789902",
				contact.toString());
	}
	
	@Test
	public void testEquals() {
		Contact contact = new Contact();
		assertTrue("Should not be equal", contact.equals(new Contact()));
	}
	
	@Test
	public void testCompareTo() {
		Contact fred = new Contact("Fred", "789902");
		Contact alison = new Contact("Alison", "0456456");
		
		int result = fred.compareTo(fred);
		assertTrue("Should be equal", 0 == result);
		
		result = fred.compareTo(alison);
		assertTrue("Should be greater than", result > 0);
		
		result = alison.compareTo(fred);
		assertTrue("Should be greater than", result < 0);
	}
}
