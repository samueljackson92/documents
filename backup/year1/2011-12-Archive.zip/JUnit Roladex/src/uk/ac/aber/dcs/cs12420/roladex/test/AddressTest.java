package uk.ac.aber.dcs.cs12420.roladex.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.roladex.Address;
import uk.ac.aber.dcs.cs12420.roladex.CountryCode;

public class AddressTest {

	private Address a;
	private String test;
	
	@Before
	public void initTest(){
		a = new Address();
		test = "test";
	}
	
	@Test
	public void testGetSetHouseNameNum() {
		a.setHouseNameNum(test);
		assertEquals("Should be test", a.getHouseNameNum(), test);
	}

	@Test
	public void testGetSetStreetName() {
		a.setStreetName(test);
		assertEquals("Should be test", a.getStreetName(), test);
	}

	@Test
	public void testGetSetTown() {
		a.setTown(test);
		assertEquals("Should be test", a.getTown(), test);
	}

	@Test
	public void testGetSetCountry() {
		a.setCountry(CountryCode.UK);
		assertEquals("Should be null", CountryCode.UK, a.getCountry());
	}

	@Test
	public void testGetSetPostZipCode() {
		a.setPostZipCode(test);
		assertEquals("Should be null", a.getPostZipCode(), test);
	}

}
