This project contains the Roladex application. 

This version of the project is the starting point for the 
JUnit worksheet. Your task is to add tests to this code and 
run the tests. You are also asked to make some changes 
to the code and then test that it still functions as 
appropriate. 

See the worksheet details for the tasks that you 
should complete. 