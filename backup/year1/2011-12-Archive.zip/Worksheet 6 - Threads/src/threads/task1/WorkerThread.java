package threads.task1;

public class WorkerThread extends Thread {
	private boolean continueRunning = true;
	public WorkerThread(){
		super("My First Thread");
	}
	
	@Override
	public void run(){
		int count = 0;
		
		
		while(continueRunning){
			System.out.println("Hello, threads loop " + count);
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			count++;
		}
	}
	
	public void finish(){
		continueRunning = false;
	}
}
