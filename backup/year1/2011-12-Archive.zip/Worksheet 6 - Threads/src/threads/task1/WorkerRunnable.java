package threads.task1;

public class WorkerRunnable implements Runnable {
	
	@Override
	public void run() {
		while (true){
			System.out.println("Hi from a runnable thread!");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
