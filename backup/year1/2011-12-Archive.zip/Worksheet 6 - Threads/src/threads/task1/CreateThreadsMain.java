package threads.task1;

import threads.ThreadUtils;

public class CreateThreadsMain {

	public static void main(String[] args) { 
		WorkerThread wt = new WorkerThread();
		wt.start();	
		
		WorkerRunnable wr = new WorkerRunnable();
		Thread runnableThread = new Thread(wr);
		runnableThread.setName("Runnable Thread");
		runnableThread.start();
		
		ThreadUtils.showThreadNames();
		
		System.out.println();
		
		try{
			Thread.sleep(10000);
			wt.finish();
		} catch(InterruptedException ie){
			System.out.println("Thread was interrupted");
		}
		
		ThreadUtils.showThreadNames();
	}
	
}
