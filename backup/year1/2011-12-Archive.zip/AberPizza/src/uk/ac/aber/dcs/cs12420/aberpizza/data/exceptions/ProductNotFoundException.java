package uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions;

/**
 * The Class ProductNotFoundException.
 * Custom exception thrown when a product could not be found.
 */
@SuppressWarnings("serial")
public class ProductNotFoundException extends Exception {
	
	/**
	 * Instantiates a new product not found exception.
	 *
	 * @param err The given error message
	 */
	public ProductNotFoundException(String err){
		super(err);
	}
}
