
package uk.ac.aber.dcs.cs12420.aberpizza.data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Discount;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.discounts.MealDealDiscount;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.discounts.ThreeLargePizzas;

/**
 * The Class Order.
 * Used to store information relating to a single customers order.
 * Information such as the date, customer name and products ordered are captured here.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class Order {
	
	/** The date the order was made. */
	private Date date;
	
	/** The customers name. */
	private String customerName;
	
	/** The items held within the order. */
	private ArrayList<OrderItem> items;
	
	/** A static (shared) array of discounts which can apply to all orders. */
	private static final Discount[] discounts = new Discount[]{new ThreeLargePizzas(), new MealDealDiscount()};

	/**
	 * Instantiates a new order.
	 */
	public Order() {
		items = new ArrayList<OrderItem>();
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString(){
		return getCustomerName() + ": " + getDate();
	}
	
	/**
	 * Sets the items held within the order.
	 *
	 * @param items the new list of items to be stored in the order
	 */
	public void setItems(ArrayList<OrderItem> items) {
		this.items = items;
	}
	
	/**
	 * Gets the items held within the order.
	 *
	 * @return The items held within the order
	 */
	public ArrayList<OrderItem> getItems() {
		return items;
	}
	
	/**
	 * Checks if an item is in the order.
	 *
	 * @param item The item to the checked
	 * @return True, if the item is in order
	 */
	public boolean isInOrder(Item item) {
		for (OrderItem i : items) {
			if(i.getItem().equals(item)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Adds an item to the order.
	 *
	 * @param item The item to be added
	 * @param quantity The quantity of the required item
	 */
	public void addItem(Item item, int amount) {
		OrderItem orderItem = new OrderItem(item, amount);
		items.add(orderItem);
	}
	
	/**
	 * Increment the given item's quantity by one.
	 *
	 * @param item The item whose quantity is to be adjusted
	 */
	public void updateItemQuantity(Item item, int amount) {
		for (OrderItem i : items) {
			if (i.getItem().equals(item)){
				i.setQuantity(amount);
			}
		}
	}
	
	/**
	 * Gets the subtotal cost for all items in the order
	 * @return The total cost of the items in the order.
	 */
	public BigDecimal getSubtotal(){
		BigDecimal total = new BigDecimal(0);
		for (OrderItem i: items) {
			total = total.add(i.getOrderItemTotal());
		}
		return total;
	}
	
	/**
	 * Gets the total cost of all items in the order, including any discounts
	 * 
	 * @return The total cost of all items in the order, plus discounts.
	 */
	public BigDecimal getTotal() {
		BigDecimal total = getSubtotal();
		total = total.add(getDiscount());
		return total;
	}
	
	/**
	 * Gets the best discount applicable for the items in this order.
	 *
	 * @return The discount (if no discount, returns 0)
	 */
	public BigDecimal getDiscount() {
		BigDecimal currentMax = new BigDecimal(0);
		for (Discount d : discounts){
			currentMax = currentMax.min(d.calculate(this));
		}
		return currentMax;
	}
	
	/**
	 * Gets the receipt for this order.
	 *
	 * @return The receipt
	 */
	public String getReceipt() {
		String htmlOutput = "";
		
		htmlOutput += "<h2>ORDER RECEIPT</h2>";
		htmlOutput += "<h4>Date: " + getDate().toString() + "</h4>";
		
		for (OrderItem i : items) {
			Item item = i.getItem();
			htmlOutput += "<h3>" + item.getDescription() + " - Qty: "+ i.getQuantity() +
			" - Size: " + item.getSize() + " - Price: " + i.getOrderItemTotal() + "</h3>";
			
		}
		
		htmlOutput += "</ul>";
		htmlOutput += "<h3>Discount: �"+ this.getDiscount() + " Total: �"+ this.getTotal() + "</h3>";
		
		return htmlOutput;
	}

	/**
	 * Gets the date this order was made.
	 *
	 * @return The date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * Sets the date for this order.
	 *
	 * @param date The new date for this order
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * Gets the customers name.
	 *
	 * @return The customer name
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * Sets the customers name.
	 *
	 * @param customerName the new customer name
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * Removes the item from the order.
	 *
	 * @param selectedIndex The index of the item in the list.
	 */
	public void removeItem(int selectedIndex) {
		items.remove(selectedIndex);
	}
}
