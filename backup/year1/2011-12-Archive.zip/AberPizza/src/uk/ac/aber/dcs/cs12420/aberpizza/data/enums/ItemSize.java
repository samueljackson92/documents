package uk.ac.aber.dcs.cs12420.aberpizza.data.enums;

/**
 * The Enum ItemSize.
 * Specifies what size an item is.
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public enum ItemSize {
	SMALL, 
	MEDIUM, 
	LARGE, 
	STANDARD
}
