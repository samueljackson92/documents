package uk.ac.aber.dcs.cs12420.aberpizza.tests;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Pizza;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.TieredProduct;

public class TieredProductTest {
	private BigDecimal[] prices;
	private TieredProduct tp;
	
	@Before
	public void init(){
		tp = new Pizza();
		prices = new BigDecimal[]{new BigDecimal(1), new BigDecimal(2), new BigDecimal(3)};
		tp.setPrices(prices);
	}
	
	@Test
	public void testModifySmallPrices(){
		tp.setSize(ItemSize.SMALL);
		assertTrue("Should be true", prices[0].equals(tp.getPrice()));
	}
	
	@Test
	public void testModifyMedPrice(){
		tp.setSize(ItemSize.MEDIUM);
		assertTrue("Should be true", prices[1].equals(tp.getPrice()));
	}
	
	@Test
	public void testModifyLargePrice(){
		tp.setSize(ItemSize.LARGE);
		assertTrue("Should be true", prices[2].equals(tp.getPrice()));
	}
}
