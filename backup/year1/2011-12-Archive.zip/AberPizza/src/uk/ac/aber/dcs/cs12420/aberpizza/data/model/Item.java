package uk.ac.aber.dcs.cs12420.aberpizza.data.model;

import java.math.BigDecimal;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;

/**
 * The Interface Item.
 * Provides a contract for different types of items to implement.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public interface Item {
	
	/**
	 * Gets the price of an item.
	 *
	 * @return the price
	 */
	public BigDecimal getPrice();
	
	/**
	 * Sets the price of an item.
	 *
	 * @param price The new price
	 */
	public void setPrice(BigDecimal price);
	
	/**
	 * Gets the description of an item.
	 *
	 * @return The description
	 */
	public String getDescription();
	
	/**
	 * Sets the description of an item.
	 *
	 * @param description The new description
	 */
	public void setDescription(String description);
	
	/**
	 * Gets the type of the item.
	 *
	 * @return the type of the item
	 */
	public ItemType getType();
	
	/**
	 * Gets the size of the item.
	 *
	 * @return the size of the item
	 */
	public ItemSize getSize();
	
	/**
	 * Sets the size of the item.
	 *
	 * @param size the new item size
	 */
	public void setSize(ItemSize size);
}
