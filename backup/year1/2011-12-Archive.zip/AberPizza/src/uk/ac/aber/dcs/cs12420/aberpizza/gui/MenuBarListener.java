package uk.ac.aber.dcs.cs12420.aberpizza.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions.ItemNotSelectedException;
import uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions.ProductNotFoundException;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.TieredProduct;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog.DailySalesHistory;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog.ProductAdminDialog;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog.OrdersWindow;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog.TieredProductAdminDialog;

/**
 * The Class MenuBarListener.
 * Implements {@code ActionListener} to listen for events from the TillWindow's menu bar.
 *
 *@author Samuel Jackson (slj11@aber.ac.uk)
 */
public class MenuBarListener implements ActionListener {
	
	/** The parent window. */
	private TillWindow parent;
	
	/**
	 * Instantiates a new menu bar listener.
	 *
	 * @param parent the parent window
	 */
	public MenuBarListener (TillWindow parent) {
		this.parent = parent;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if (parent.getContentPane().isEnabled()){
			//decide on the action to perform from the menu

			if (command.equals("Pizza")|| command.equals("Side")|| command.equals("Drink")) {
				Product p = null;
				try {
					p = (Product) Class.forName("uk.ac.aber.dcs.cs12420.aberpizza.data.model."+command).newInstance();
				} catch (Exception ex) {
					new ErrorHandler(parent, ex, ErrorHandler.ERROR);
				}
				
				if(p == null){
					new ErrorHandler(parent, "Error loading product template.", ErrorHandler.ERROR);
				}
				
				if(p instanceof TieredProduct){
					new TieredProductAdminDialog(parent, (TieredProduct) p);
				} else {
					new ProductAdminDialog(parent, p);
				}
			} else if (command.equals("Edit")) {
				Product p = null;
	
				try {
					p = parent.getSelectedLibraryItem();
				} catch (ItemNotSelectedException ex) {
					new ErrorHandler(parent, ex, ErrorHandler.INFO);
					return;
				} catch (ProductNotFoundException ex) {
					new ErrorHandler(parent, ex, ErrorHandler.ERROR);
					return;
				}
				
				switch(parent.getLibraryState()) {
					case PIZZA:
						new TieredProductAdminDialog(parent,(TieredProduct) p, true);
						break;
					case DRINK: case SIDE:
						new ProductAdminDialog(parent, p, true);
						break;
						
				}
			} else if (command.equals("Edit Quantity")){
				try {
					int quant = Integer.parseInt(JOptionPane.showInputDialog("Input new quantity:"));
					parent.updateItem(quant);
				}catch(NumberFormatException ex){
					new ErrorHandler(parent, ex, ErrorHandler.ERROR);
				}
			} else if (command.equals("Remove")){
				parent.removeLibraryItem();
			} else if (command.equals("Remove From Order")){
				parent.removeOrderItem();
			}
		}
		
		if (command.equals("Close Till")) {
			parent.saveTill();
		} else if (command.equals("Open Till")) {
			parent.loadTill();
		} else if (command.equals("View Orders")){
			new OrdersWindow(parent, "View Orders");
		} else if(command.equals("Exit")) {
			parent.saveTill();
			System.exit(0);
		} else if (command.equals("View Today's Total")){
			JOptionPane.showMessageDialog(parent, "Total for today is:\n�" + parent.getDailyTotal());
		} else if (command.equals("View Sales History")){
			new DailySalesHistory(parent, "Daily Sales History", parent.getTill().getOrders());
		} else if(command.equals("About")) {
			JOptionPane.showMessageDialog(parent, "Created by Samuel Jackson (slj11) \u00a9 2012");
		}
	}
}
