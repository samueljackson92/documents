package uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog;

import java.awt.Component;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;

import javax.swing.JOptionPane;
import javax.swing.JTextPane;

import uk.ac.aber.dcs.cs12420.aberpizza.gui.ErrorHandler;

/**
 * The Class PrintJobThread.
 * Creates a separate thread for printing, so that the GUI does not get locked
 * up waiting for the printer to respond.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class PrintJobThread implements Runnable {

	/** The printable. */
	private JTextPane printable;
	
	/**
	 * Gets the printable object.
	 *
	 * @return The printable object
	 */
	public JTextPane getPrintable() {
		return printable;
	}
	
	/**
	 * Sets the printable object.
	 *
	 * @param obj The new printable object
	 */
	public void setPrintable(JTextPane obj) {
		this.printable = obj;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		try {
			printable.print();
		} catch (PrinterException e) {
			JOptionPane.showMessageDialog(null, "Printing Failed");
		}
	}

}
