package uk.ac.aber.dcs.cs12420.aberpizza.data.model;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;

/**
 * The Class Pizza.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class Pizza extends TieredProduct {
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#getType()
	 */
	@Override
	public ItemType getType() {
		return ItemType.PIZZA;
	}
}
