package uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;

/**
 * The Class DailySalesHistory.
 * Shows the sales history for the current day, along with how many sales and how much was taken
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
@SuppressWarnings("serial")
public class DailySalesHistory extends AdminDialog implements ActionListener {
	
	/** The daily sales. */
	private JTextPane dailySales;
	
	/**
	 * Instantiates a new daily sales history.
	 *
	 * @param parent The parent window
	 * @param title The title of this window
	 * @param orders The list of past orders.
	 */
	public DailySalesHistory(JFrame parent, String title, ArrayList<Order> orders) {
		super(parent, title);
		setLayout(new BorderLayout());
		
		dailySales = new JTextPane();
		dailySales.setContentType("text/html");
		dailySales.setEditable(false);
		
		JScrollPane scroll = new JScrollPane(dailySales);
		scroll.setPreferredSize(new Dimension(400, 200));
		add(scroll, BorderLayout.NORTH);
		

		JButton print = new JButton("Print");
		JButton cancel = new JButton("Cancel");
		
		print.addActionListener(this);
		cancel.addActionListener(this);
	
		JPanel buttons = new JPanel();
		
		buttons.add(print);
		buttons.add(cancel);
		
		add(buttons, BorderLayout.CENTER);
		
		String html = "";
		Date today = new Date();
		int totalSales = 0;
		BigDecimal total = new BigDecimal(0);
		SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
		
		for (Order o : orders){
			if(fmt.format(o.getDate()).equals(fmt.format(today))){
				totalSales++;
				html += o.getReceipt();
				total = total.add(o.getTotal());
			}
		}
		
		dailySales.setText("<h1>Daily Sales History</h1><h2>Total Sales: "+totalSales+" Today's Total: �"+total+"</h2><br />" + html);
		dailySales.setCaretPosition(0);
		
		pack();
		setVisible(true);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if(command.equals("Print")){
			PrintJobThread pjt = new PrintJobThread();
			pjt.setPrintable(dailySales);
			Thread printThread = new Thread(pjt);
			printThread.start();
		} else if (command.equals("Cancel")){
			this.dispose();
		}

	}

}
