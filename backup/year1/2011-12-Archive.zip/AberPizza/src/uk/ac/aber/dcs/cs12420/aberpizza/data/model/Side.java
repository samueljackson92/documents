package uk.ac.aber.dcs.cs12420.aberpizza.data.model;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;

/**
 * The Class Side.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class Side extends SingleProduct {
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#getType()
	 */
	@Override
	public ItemType getType() {
		return ItemType.SIDE;
	}

}
