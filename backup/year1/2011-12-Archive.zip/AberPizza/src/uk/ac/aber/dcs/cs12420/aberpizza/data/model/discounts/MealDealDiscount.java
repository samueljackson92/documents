package uk.ac.aber.dcs.cs12420.aberpizza.data.model.discounts;

import java.math.BigDecimal;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;
import uk.ac.aber.dcs.cs12420.aberpizza.data.OrderItem;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Discount;

/**
 * The Class MealDealDiscount.
 * A discount which gives the customer �5 off if they buy 1 side, 1 drink and 1 pizza.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class MealDealDiscount extends Discount {

	/**
	 * Instantiates a new meal deal discount.
	 */
	public MealDealDiscount(){
		setDescription("Meal Deal Discount");
		setPrice(new BigDecimal("-5.00"));
	}
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Discount#calculate(uk.ac.aber.dcs.cs12420.aberpizza.data.Order)
	 */
	@Override
	public BigDecimal calculate(Order order) {
		int p=0,s=0,d=0;
		for (OrderItem i : order.getItems()){
			switch(i.getItem().getType()){
				case PIZZA:
					p++;
					break;
				case SIDE:
					s++;
					break;
				case DRINK:
					d++;
					break;
			}
			
			if(p >= 1 && s >= 1 && d >= 1){
				return getPrice();
			}
		}
		
		return new BigDecimal(0);
	}

}
