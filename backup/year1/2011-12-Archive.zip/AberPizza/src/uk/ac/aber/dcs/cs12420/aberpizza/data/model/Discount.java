package uk.ac.aber.dcs.cs12420.aberpizza.data.model;

import java.math.BigDecimal;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;

/**
 * The Class Discount.
 * Abstract class designed to specify the template from creating new types of discounts.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public abstract class Discount extends SingleProduct {
	
	/**
	 * Calculate whether the discount is applicable for this order.
	 *
	 * @param order The order to be checked
	 * @return The discoutn price (either negative or 0)
	 */
	public abstract BigDecimal calculate(Order order);
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#getType()
	 */
	public ItemType getType() {
		return ItemType.DISCOUNT;
	}
}
