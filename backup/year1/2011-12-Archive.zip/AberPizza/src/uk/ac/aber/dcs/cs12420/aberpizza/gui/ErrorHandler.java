package uk.ac.aber.dcs.cs12420.aberpizza.gui;

import java.awt.Component;

import javax.swing.JOptionPane;

/**
 * The Class ErrorHandler.
 * Handles errors by creating an informational message to the user.
 * Messages are displayed using {@code JOptionPane}
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class ErrorHandler {
	
	/** The Constant INFO. For information messages */
	public static final int INFO = JOptionPane.NO_OPTION;
	
	/** The Constant ERROR. For erroneous messages */
	public static final int ERROR = JOptionPane.ERROR_MESSAGE;
	
	/**
	 * Instantiates a new error handler.
	 *
	 * @param parent The parent component
	 * @param message The message to be displayed
	 * @param type The type of the message
	 */
	public ErrorHandler(Component parent, String message, int type){
		switch(type) {
			case ERROR:
				JOptionPane.showMessageDialog(parent, message, "Error", ERROR);
				break;
			case INFO:
				JOptionPane.showMessageDialog(parent, message, "Information", INFO);
				break;
		}
		
	}
	
	/**
	 * Instantiates a new error handler.
	 *
	 * @param parent the parent components
	 * @param e The exception passed
	 * @param type The type of message
	 */
	public ErrorHandler(Component parent, Exception e, int type) {
		this(parent, e.getMessage(), type);
	}
}
