package uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions;

/**
 * The Class ItemNotSelectedException.
 * Custom exception thrown when an item has not been selected in a JListBox
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
@SuppressWarnings("serial")
public class ItemNotSelectedException extends Exception {
	
	/**
	 * Instantiates a new item not selected exception.
	 *
	 * @param err The given error message.
	 */
	public ItemNotSelectedException(String err){
		super(err);
	}
}
