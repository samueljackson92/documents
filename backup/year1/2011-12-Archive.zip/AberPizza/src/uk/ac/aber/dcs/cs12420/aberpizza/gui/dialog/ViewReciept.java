package uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;

/**
 * The Class ViewReciept.
 * Class for outputting and viewing an individual receipt from an order.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
@SuppressWarnings("serial")
public class ViewReciept extends AdminDialog implements ActionListener {
	
	/** The TextPane to output the receipt. */
	private JTextPane receipt;
	
	/**
	 * Instantiates a new view receipt.
	 *
	 * @param parent The parent window
	 * @param title The window title
	 * @param order The order to be output
	 */
	public ViewReciept(JFrame parent, String title, Order order) {
		super(parent, title);
		JPanel content = new JPanel();
		content.setLayout(new BorderLayout());
		
        receipt = new JTextPane();
        receipt.setEditable(false);
        receipt.setContentType("text/html");
        receipt.setText(order.getReceipt());
        
        JButton print = new JButton("Print");
        JButton close = new JButton("Close");
        print.addActionListener(this);
        close.addActionListener(this);
        
        JPanel buttons = new JPanel();
        buttons.add(print);
        buttons.add(close);
        
        content.add(new JScrollPane(receipt), BorderLayout.NORTH);
        content.add(buttons, BorderLayout.CENTER);
        add(content);
        
		pack();
		setVisible(true);
	}
	
	/**
	 * Gets the printable component.
	 *
	 * @return the printable component
	 */
	public JTextPane getPrintable(){
		return receipt;
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if (command.equals("Print")){
			PrintJobThread pjt = new PrintJobThread();
			pjt.setPrintable(receipt);
			Thread printThread = new Thread(pjt);
			printThread.start();
		} else if (command.equals("Close")){
			this.dispose();
		}
	}

}
