package uk.ac.aber.dcs.cs12420.aberpizza.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Drink;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Pizza;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Side;

public class ProductTest {

	@Test
	public void testModifyProductDescription(){
		Product p = new Pizza();
		String s = "Yum";
		p.setDescription(s);
		assertEquals("Strings should be equal", s, p.getDescription());
	}

	@Test
	public void testModifyProductSize() {
		Product p = new Pizza();
		p.setSize(ItemSize.SMALL);
		assertEquals("Item sizes should be equal", ItemSize.SMALL, p.getSize());
	}

	@Test
	public void testGetPizza() {
		assertEquals(new Pizza().getType(), ItemType.PIZZA);
	}
	
	@Test
	public void testGetSide(){
		assertEquals(new Side().getType(), ItemType.SIDE);
	}
	
	@Test
	public void testGetDrink(){
		assertEquals(new Drink().getType(), ItemType.DRINK);	
	}

	
	@Test
	public void testEqualsItem(){
		Product p = new Pizza();
		p.setDescription("hello");
		p.setSize(ItemSize.SMALL);
		
		Product p2 = new Pizza();
		p2.setDescription("hello");
		p2.setSize(ItemSize.SMALL);
		
		assertTrue("Should return true", p.equals(p2));

	}
	
	@Test
	public void testNotEqualsItem(){
		Product p = new Pizza();
		p.setDescription("hello");
		p.setSize(ItemSize.SMALL);
		
		Product p3 = new Pizza();
		assertFalse("Should return false", p.equals(p3));
	}

	@Test
	public void testCopyProduct() {
		Product p = new Pizza();
		p.setDescription("Hello");
		p.setSize(ItemSize.MEDIUM);
		
		Product p2 = p.copy();
		
		assertTrue("Should return true", p2.equals(p));
	}
}
