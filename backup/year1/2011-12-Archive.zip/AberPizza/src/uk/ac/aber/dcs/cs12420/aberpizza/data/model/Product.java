package uk.ac.aber.dcs.cs12420.aberpizza.data.model;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.ErrorHandler;

// TODO: Auto-generated Javadoc
/**
 * The Class Product.
 * Abstract class which implements the shared functionality of all items.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public abstract class Product implements Item {
	
	/** The size of the product (default of {@code ItemSize.STANDARD}). */
	private ItemSize size = ItemSize.STANDARD;
	
	/** The description of the product. */
	private String description = "";
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#getDescription()
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#setDescription(java.lang.String)
	 */
	@Override
	public void setDescription(String description) {
		this.description = description;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj){
		Item item = (Item) obj;
		if(getType() == item.getType() && getDescription().equals(item.getDescription()) 
				&& getSize() == item.getSize()) {
			return true;
		}
		return false;
	}
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#getSize()
	 */
	public ItemSize getSize() {
		return size;
	}
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#setSize(uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize)
	 */
	public void setSize(ItemSize size) {
		this.size = size;
	}
	
	
	/**
	 * Copy one instance of a product to another.
	 *
	 * @return the copied product.
	 */
	public Product copy() {
		try {
			Product p = this.getClass().newInstance();
			p.setDescription(getDescription());
			p.setSize(getSize());
			
			return p;
		} catch (InstantiationException e) {
			new ErrorHandler(null, e.getMessage(), ErrorHandler.ERROR);
		} catch (IllegalAccessException e) {
			new ErrorHandler(null, e.getMessage(), ErrorHandler.ERROR);
		}
		return null;
	}

}
