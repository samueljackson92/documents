package uk.ac.aber.dcs.cs12420.aberpizza.data.model;

import java.math.BigDecimal;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize;

// TODO: Auto-generated Javadoc
/**
 * The Class SingleProduct.
 * Abstract that implements shared functionality between all items that only have one price tier.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public abstract class SingleProduct extends Product {
	
	/** The price of the Single Product. */
	private BigDecimal price = new BigDecimal("0.0");
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#getPrice()
	 */
	@Override
	public BigDecimal getPrice() {
		return price;
	}

	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#setPrice(java.math.BigDecimal)
	 */
	@Override
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product#getSize()
	 */
	@Override
	public ItemSize getSize(){
		return ItemSize.STANDARD;
	}
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product#copy()
	 */
	@Override
	public Product copy(){
		Product p = super.copy();
		p.setPrice(getPrice());
		return p;
	}

}
