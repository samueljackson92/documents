package uk.ac.aber.dcs.cs12420.aberpizza.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;
import uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions.ItemNotSelectedException;
import uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions.ProductNotFoundException;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.TieredProduct;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog.PayDialog;

/**
 * ButtonListener
 * Implements {@code ActionListener} for listening to events from the {@code TillWindow}
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class ButtonListener implements ActionListener {
	
	/** The parent. */
	private TillWindow parent;
	
	/**
	 * Instantiates a new button listener.
	 *
	 * @param parent the parent window
	 */
	public ButtonListener (TillWindow parent) {
		this.parent = parent;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if(command.equals(ItemType.PIZZA.toString()) || command.equals(ItemType.SIDE.toString()) || command.equals(ItemType.DRINK.toString())) {
			parent.setSizeOptionEnabled(false);
			
			if (command.equals(ItemType.PIZZA.toString())) {
				parent.setSizeOptionEnabled(true);
			}
			parent.loadLibrary(ItemType.valueOf(command));
		} else if(command.equals("Add To Order")) {
			Product item = null;
			try {
				item = parent.getSelectedLibraryItem();
			} catch (ItemNotSelectedException ex) {
				new ErrorHandler(parent, ex, ErrorHandler.INFO);
				return;
			} catch (ProductNotFoundException ex) {
				new ErrorHandler(parent, ex, ErrorHandler.ERROR);
				return;
			}
			
			if(item instanceof TieredProduct){
				((TieredProduct) item).setSize(parent.getSelectedSize());
			}
			parent.addToOrder(item);
		} else if (command.equals("Pay")){
			//if order is valid then pay for it.
			if (parent.validateOrder()){
				new PayDialog(parent, "Pay for Order");
			}
		} else if (command.equals("Cancel")){
			parent.clearOrder();
		}
	}
	
}
