package uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.ErrorHandler;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.TillWindow;

/**
 * The Class RecieptsWindow.
 * Window which is used to output and display a list of orders.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
@SuppressWarnings("serial")
public class OrdersWindow extends AdminDialog implements ActionListener {

	/** The receipts list. */
	JList receiptsList;
	
	/**
	 * Instantiates a new receipts window.
	 *
	 * @param parent The parent window
	 * @param title The title of the window
	 */
	public OrdersWindow(TillWindow parent, String title) {
		super(parent, title);
		setLayout(new BorderLayout());
		
		JPanel top = new JPanel();
		receiptsList = new JList(parent.getTill().getOrders().toArray());
		
		top.add(new JScrollPane(receiptsList));
		
		JPanel center = new JPanel();
		JButton view = new JButton("View Reciept");
		view.addActionListener(this);
		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(this);
		center.add(view);
		center.add(cancel);
		
		add(top, BorderLayout.NORTH);
		add(center, BorderLayout.CENTER);
		
		pack();
		setVisible(true);
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command  = e.getActionCommand();
		if(command.equals("View Reciept")){
			if(receiptsList.getSelectedIndex() >= 0){
				Order order = ((TillWindow)getParent()).getTill().getOrders().get(receiptsList.getSelectedIndex());
				new ViewReciept(getParent(), "View Reciept", order);
			} else {
				new ErrorHandler(getParent(), 
						"No reciept has been selected!\n Please select an item.", 
						ErrorHandler.INFO);
			}
		} else if (command.equals("Cancel")){
			this.dispose();
		}
		
	}

}
