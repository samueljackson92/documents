/*
 * 
 */
package uk.ac.aber.dcs.cs12420.aberpizza.data.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum ItemType.
 * Specifies what type an item is.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public enum ItemType {
	PIZZA, 
	SIDE, 
	DRINK, 
	DISCOUNT
}
