package uk.ac.aber.dcs.cs12420.aberpizza.tests;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.aberpizza.data.XMLIO;

public class XMLIOTest {

	private XMLIO xml;

	@Before
	public void init(){
		xml = new XMLIO();
	}
	
	@Test
	public void testEncodeObject(){
		try {
			xml.encodeObject(new Object(), "test.xml");
			File f = new File("test.xml");
			assertTrue(f.exists());
		} catch (IOException e) {
			fail("An IOException occured");
		}
	}
	
	@Test
	public void testDecodeObject(){
		try {
			Object obj = xml.decodeObject("test.xml");
			assertNotNull(obj);
		} catch (FileNotFoundException e) {
			fail("Could not find file");
		}
	}
}
