package uk.ac.aber.dcs.cs12420.aberpizza.data.model;

import java.math.BigDecimal;

// TODO: Auto-generated Javadoc
/**
 * The Class TieredProduct.
 * Abstract class which implements shared functionality between all products that have multiple price tiers
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public abstract class TieredProduct extends Product {
	
	/** The different prices of the product. */
	private BigDecimal[] prices;
	
	/**
	 * Instantiates a new tiered product.
	 */
	public TieredProduct() {
		prices = new BigDecimal[3];
	}
	
	/**
	 * Gets the prices of this product.
	 *
	 * @return The prices
	 */
	public BigDecimal[] getPrices() {
		return prices;
	}

	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#getPrice()
	 */
	@Override
	public BigDecimal getPrice() {
		switch(getSize()) {
			case SMALL:
				return prices[0];
			case MEDIUM:
				return prices[1];
			case LARGE:
				return prices[2];
			default:
				return prices[0];
		}
	}
	
	/**
	 * Sets the prices of this product.
	 *
	 * @param prices the new prices
	 */
	public void setPrices(BigDecimal[] prices) {
		this.prices = prices;
	}
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#setPrice(java.math.BigDecimal)
	 */
	@Override
	public void setPrice(BigDecimal price) {
		this.prices = new BigDecimal[]{price, price, price};
	}
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product#copy()
	 */
	@Override
	public Product copy(){
		Product p = super.copy();
		((TieredProduct) p).setPrices(getPrices());
		return p;
	}
}
