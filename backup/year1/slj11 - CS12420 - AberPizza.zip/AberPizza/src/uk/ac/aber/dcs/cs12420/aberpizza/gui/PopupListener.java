package uk.ac.aber.dcs.cs12420.aberpizza.gui;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPopupMenu;

// TODO: Auto-generated Javadoc
/**
 * The Class PopopListener.
 * Implements {@code MouseAdapter} to listen and handle events from a given popup menu.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class PopupListener extends MouseAdapter {
	
	/** The popup to show. */
	JPopupMenu popup;
	
	/**
	 * Instantiates a new popup listener.
	 *
	 * @param popup the popup to show
	 */
	public PopupListener(JPopupMenu popup){
		this.popup = popup;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseAdapter#mousePressed(java.awt.event.MouseEvent)
	 */
	public void mousePressed(MouseEvent e){
		maybeShowPopup(e);
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseAdapter#mouseReleased(java.awt.event.MouseEvent)
	 */
	public void mouseReleased(MouseEvent e){
		maybeShowPopup(e);
	}
	
	/**
	 * Maybe show popup.
	 *
	 * @param e The mouse event
	 */
	public void maybeShowPopup(MouseEvent e){
		if(e.isPopupTrigger()){
			 popup.show(e.getComponent(), e.getX(), e.getY());
		}
	}
}
