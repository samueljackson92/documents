package uk.ac.aber.dcs.cs12420.aberpizza.tests;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Discount;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Pizza;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.discounts.ThreeLargePizzas;

public class ThreeLargePizzasTest {

	private Order order;
	private Discount discount;

	@Before
	public void init(){
		order = new Order();
		discount = new ThreeLargePizzas();
	}

	@Test
	public void testCalculateValidThreeLargePizzasDiscount(){
		Pizza p = new Pizza();
		p.setSize(ItemSize.LARGE);
		order.addItem(p, 3);
		
		BigDecimal price = discount.calculate(order);
		assertEquals("Should be equal", discount.getPrice(),price);
	}

	@Test
	public void testCalculateInvalidThreeLargePizzasDiscount(){
		Pizza p = new Pizza();
		p.setSize(ItemSize.LARGE);
		order.addItem(p, 2);
		
		BigDecimal price = discount.calculate(order);
		assertEquals("Should be equal", new BigDecimal(0),price);
	}

	@Test
	public void testEmptyOrder(){
		BigDecimal price = discount.calculate(order);
		assertEquals("Should be equal", new BigDecimal(0),price);
	}
}
