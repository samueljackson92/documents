package uk.ac.aber.dcs.cs12420.aberpizza.data;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * The Class Till.
 * Controls a list of orders which can be added to.
 * It can also load and save the list of orders.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class Till {
	
	/** The orders taken by this till. */
	private ArrayList<Order> orders;
	
	/**
	 * Instantiates a new till.
	 */
	public Till() {
		orders = new ArrayList<Order>();
	}
	
	/**
	 * Sets the list of orders.
	 *
	 * @param orders The new list of orders
	 */
	public void setOrders(ArrayList<Order> orders) {
		this.orders = orders;
	}

	/**
	 * Gets the list of orders.
	 *
	 * @return the list of orders
	 */
	public ArrayList<Order> getOrders() {
		return orders;
	}

	/**
	 * Adds an order to this till.
	 *
	 * @param order The order to be added
	 */
	public void addOrder(Order order) {
		orders.add(order);
	}

	/**
	 * Gets the total taken for the day by this till.
	 *
	 * @return the total for the day
	 */
	public BigDecimal getTotalForTheDay() {
		BigDecimal total = new BigDecimal("0.00");
		Date today = new Date();
		SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
		
		for (Order o : orders) {
			if(fmt.format(o.getDate()).equals(fmt.format(today))){
				total = total.add(o.getTotal());
			}
		}
		return total;
	}

	/**
	 * Save data in this till to an xml file.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public void save() throws IOException {
		XMLIO xmlrunner = new XMLIO();
		xmlrunner.encodeObject(this, "till.xml");
	}

	/**
	 * Load a till object from an xml file.
	 *
	 * @return the till that was loaded
	 * @throws FileNotFoundException Signals that the required file could not be found.
	 */
	public static Till load() throws IOException {
		XMLIO xmlrunner = new XMLIO();
		Object obj = xmlrunner.decodeObject("till.xml");
		return (Till) obj;
	}
}
