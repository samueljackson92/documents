package uk.ac.aber.dcs.cs12420.aberpizza.tests;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.aberpizza.data.ProductLibrary;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;
import uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions.ProductNotFoundException;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Drink;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Pizza;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Side;

public class ProductLibraryTest {

	private ProductLibrary productLibrary;

	@Before
	public void init(){
		productLibrary = new ProductLibrary();
	}

	@Test
	public void testModiyDrinks(){
		productLibrary.setDrinks(new ArrayList<Drink>());
		assertNotNull(productLibrary.getDrinks());
	}
	public void testModiyPizzas(){
		productLibrary.setPizzas(new ArrayList<Pizza>());
		assertNotNull(productLibrary.getPizzas());
	}
	public void testModiySides(){
		productLibrary.setSides(new ArrayList<Side>());
		assertNotNull(productLibrary.getSides());
	}	

	@Test
	public void testAddProduct(){
		productLibrary.addProduct(new Pizza());
		assertTrue("Should be true", productLibrary.getPizzas().size() == 1);
	}

	private void testGetProductInit(){
		Pizza cheese = new Pizza();
		cheese.setDescription("Cheese");
		Pizza ham = new Pizza();
		ham.setDescription("Ham");
		Pizza pepperoni = new Pizza();
		pepperoni.setDescription("Pepperoni");
		
		productLibrary.addProduct(cheese);
		productLibrary.addProduct(ham);
		productLibrary.addProduct(pepperoni);
		
		Side s = new Side();
		s.setDescription("Toast");
		productLibrary.addProduct(s);
	}
	@Test
	public void testGetProductMiddle(){
		testGetProductInit();
		
		try {
			Product p = productLibrary.findProduct("Ham", ItemType.PIZZA);
			assertTrue(p.getDescription().equals("Ham"));
		} catch (ProductNotFoundException e) {
			fail("Should of found the product");
		}
	}
	
	@Test
	public void testGetProductFirst(){
		testGetProductInit();
		
		try {
			
			Product p = productLibrary.findProduct("Cheese", ItemType.PIZZA);
			assertTrue(p.getDescription().equals("Cheese"));
			
		} catch (ProductNotFoundException e) {
			fail("Should of found the product");
		}
	}
	
	@Test
	public void testGetProductLast(){
		testGetProductInit();
		
		try {
			Product p = productLibrary.findProduct("Pepperoni", ItemType.PIZZA);
			assertTrue(p.getDescription().equals("Pepperoni"));
			
			
		} catch (ProductNotFoundException e) {
			fail("Should of found the product");
		}
	}
	
	@Test
	public void testGetProductOtherList(){
		testGetProductInit();
		
		try {	
			Product p = productLibrary.findProduct("Toast", ItemType.SIDE);
			assertTrue(p.getDescription().equals("Toast"));
		} catch (ProductNotFoundException e) {
			fail("Should of found the product");
		}
		

	}
	
	@Test
	public void testGetProductThatDoesntExist(){
		testGetProductInit();
		
		try {
			productLibrary.findProduct("Meat Feast", ItemType.PIZZA);
			fail("Should of thrown an exception");
		} catch (ProductNotFoundException e) {
			assertNotNull(e.getMessage());
		}
	}

	@Test
	public void testRemoveItem(){
		Pizza cheese = new Pizza();
		cheese.setDescription("Cheese");
		Pizza ham = new Pizza();
		ham.setDescription("Ham");
		Pizza pepperoni = new Pizza();
		pepperoni.setDescription("Pepperoni");
		
		productLibrary.addProduct(cheese);
		productLibrary.addProduct(ham);
		productLibrary.addProduct(pepperoni);
		
		productLibrary.removeItem(ham);
		try {
			productLibrary.findProduct("Ham", ItemType.PIZZA);
			fail("Should not of found the product");
		} catch (ProductNotFoundException e) {
			assertTrue(productLibrary.getPizzas().size() == 2);
		}	
	}

	@Test
	public void testSaveLibrary() throws IOException{
		Pizza cheese = new Pizza();
		cheese.setDescription("Cheese");
		Pizza ham = new Pizza();
		ham.setDescription("Ham");
		Pizza pepperoni = new Pizza();
		pepperoni.setDescription("Pepperoni");
		
		productLibrary.addProduct(cheese);
		productLibrary.addProduct(ham);
		productLibrary.addProduct(pepperoni);
		
		Side s = new Side();
		s.setDescription("Toast");
		productLibrary.addProduct(s);
		
		productLibrary.saveLibrary();
		
		File f = new File("libpizzas.xml");
		assertTrue("File should exist", f.exists());
	}

	@Test
	public void testLoadLibrary(){
		try {
			productLibrary.loadLibrary();
			assertTrue(productLibrary.getPizzas().size() > 0);
		} catch (FileNotFoundException e) {
			fail("Could not find file to load");
		}
	}
}
