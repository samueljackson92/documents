package uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JFrame;

/**
 * The Class AdminDialog.
 * Abstract class that provides a generic set of components that all admin dialogs share.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
@SuppressWarnings("serial")
public abstract class AdminDialog extends JDialog implements ActionListener {
	
	/** The parent window. */
	private JFrame parent;
	
	/**
	 * Instantiates a new admin dialog.
	 *
	 * @param parent The parent window
	 * @param title The title for this window
	 */
	public AdminDialog(JFrame parent, String title) {
	    super(parent, title, true);
	    this.parent = parent;
	    
	    if (parent != null) {
	    	Dimension parentSize = parent.getSize(); 
	    	Point p = parent.getLocation(); 
	    	setLocation(p.x + parentSize.width / 4, p.y + parentSize.height / 4);
	    }
	    
		setSize(300, 200);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
	}
	
	/* (non-Javadoc)
	 * @see java.awt.Component#getParent()
	 */
	@Override
	public JFrame getParent() {
		return parent;
	}
	
	/**
	 * Sets the parent window.
	 *
	 * @param parent The new parent window
	 */
	public void setParent(JFrame parent) {
		this.parent = parent;
	}
}
