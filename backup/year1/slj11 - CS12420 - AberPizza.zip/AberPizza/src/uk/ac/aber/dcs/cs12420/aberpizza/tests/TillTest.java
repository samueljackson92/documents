package uk.ac.aber.dcs.cs12420.aberpizza.tests;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;
import uk.ac.aber.dcs.cs12420.aberpizza.data.Till;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Pizza;

public class TillTest {

	private Till till;
	private ArrayList<Order> orders;

	@Before
	public void init(){
		till = new Till();
		orders = new ArrayList<Order>();
		Order order = new Order();
		order.setDate(new Date());
		orders.add(order);
		
		for (int i=0; i< 3; i++){
			Pizza p = new Pizza();
			p.setPrice(new BigDecimal(10));
			order = new Order();
			order.setDate(new Date());
			order.addItem(p, 2);
			orders.add(order);
		}
	}

	@Test
	public void testModifyOrders(){
		till.setOrders(orders);
		assertEquals("Should be equal", orders, till.getOrders());
	}

	@Test
	public void testAddOrder() {
		till.addOrder(new Order());
		assertTrue("Should be true", till.getOrders().size() == 1);
	}

	@Test
	public void testGetTotalForTheDay() {
		till.setOrders(orders);
		assertTrue("Should be true", till.getTotalForTheDay().equals(new BigDecimal("60.00")));
	}

	@Test
	public void testSave() {
		till.setOrders(orders);
		try {
			till.save();
			File f = new File("till.xml");
			assertTrue("Should be true", f.exists());
		} catch (IOException e) {
			fail("Exception occured");
		}
	}

	@Test
	public void testLoad() {
		try {
			till = Till.load();
			assertNotNull("Should not be null", till.getOrders().get(0));
		} catch (IOException e) {
			fail("Exception occured");
		}
	}

}
