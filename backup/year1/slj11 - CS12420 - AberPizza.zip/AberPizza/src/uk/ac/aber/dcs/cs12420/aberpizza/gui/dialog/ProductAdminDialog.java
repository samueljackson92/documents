package uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.ErrorHandler;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.TillWindow;

/**
 * The Class ProductAdminDialog.
 * Creates an admin dialog for adding or editing single products.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
@SuppressWarnings("serial")
public class ProductAdminDialog extends AdminDialog implements ActionListener {
	
	/** The item description and price. */
	private JTextField description, price;
	
	/** The selected product. */
	private Product selectedProduct;
	
	/**
	 * Instantiates a new product admin dialog.
	 *
	 * @param parent The parent window
	 * @param p The product
	 */
	public ProductAdminDialog(JFrame parent, Product p){
		this(parent, p, false);
	}
	
	/**
	 * Instantiates a new product admin dialog.
	 *
	 * @param parent The parent window
	 * @param product The product
	 * @param edit Whether we are adding or editing
	 */
	public ProductAdminDialog(JFrame parent, Product product, boolean edit) {
		super(parent, "Product Admin");
	    selectedProduct = product;

		JPanel content = new JPanel();
		content.setLayout(new BorderLayout());
		
		JPanel namePanel = new JPanel();
		description = new JTextField(20);
		namePanel.add(new JLabel("Name:"));
		namePanel.add(description);
		
		JPanel pricesPanel = new JPanel();
		pricesPanel.setLayout(new FlowLayout());
		
		price = new JTextField(4);
		price.setText("0.00");
		
		pricesPanel.add(new JLabel("Price: "));
		pricesPanel.add(price);
		
		JPanel buttons = new JPanel();
		JButton submit = new JButton("Add");
		submit.addActionListener(this);
		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(this);
		buttons.add(submit);
		buttons.add(cancel);
		
		content.add(namePanel, BorderLayout.NORTH);
		content.add(pricesPanel, BorderLayout.CENTER);
		content.add(buttons, BorderLayout.SOUTH);
		add(content);
		pack();
		
		if (edit) {
			description.setText(product.getDescription());
			price.setText(product.getPrice().toString());
			
			submit.setText("Edit");
			submit.setActionCommand("Edit");
		}
		setVisible(true);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		
		if((command.equals("Add") || command.equals("Edit")) && validateForm()) {
				if(command.equals("Add")) {
					((TillWindow) getParent()).addProduct(selectedProduct);
				}
				modifyProduct();

		} else if (command.equals("Cancel")){
			this.dispose();
		}
	}
	
	private boolean validateForm(){
		if(!description.getText().isEmpty() && !price.getText().isEmpty()) {
			try{
				BigDecimal cost = new BigDecimal(price.getText());
				BigDecimal zero = new BigDecimal(0);
				if(cost.compareTo(zero) > 0){
					return true;
				}
			} catch (NumberFormatException ex){
				new ErrorHandler(getParent(), "Not numerical input!", ErrorHandler.INFO);
			}
		}
		return false;
	}
	
	private void modifyProduct() throws NumberFormatException {
		TillWindow tw = (TillWindow) getParent();
		selectedProduct.setDescription(description.getText());
		selectedProduct.setPrice(new BigDecimal(price.getText()));
		tw.loadLibrary(selectedProduct.getType());
		this.dispose();
	}
}
