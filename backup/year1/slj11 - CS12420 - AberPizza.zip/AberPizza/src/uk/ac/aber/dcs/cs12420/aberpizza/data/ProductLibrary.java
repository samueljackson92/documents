/*
 * 
 */
package uk.ac.aber.dcs.cs12420.aberpizza.data;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;
import uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions.ProductNotFoundException;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Drink;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Pizza;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Side;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.ErrorHandler;

/**
 * The Class ProductLibrary.
 * Load, saves and stores a template products that have been created and added to the system.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class ProductLibrary {
	
	/** The list of pizzas. */
	private ArrayList<Pizza> pizzas;
	
	/** The list of sides. */
	private ArrayList<Side> sides;
	
	/** The list of drinks. */
	private ArrayList<Drink> drinks;
	
	/**
	 * Instantiates a new product library.
	 */
	public ProductLibrary() {
		pizzas = new ArrayList<Pizza>();
		sides = new ArrayList<Side>();
		drinks = new ArrayList<Drink>();
	}
	
	/**
	 * Save library to xml files.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public void saveLibrary() throws IOException {
		XMLIO xmlrunner = new XMLIO();
		xmlrunner.encodeObject(pizzas, "libpizzas.xml");
		xmlrunner.encodeObject(sides, "libsides.xml");
		xmlrunner.encodeObject(drinks, "libdrinks.xml");
	}
	
	/**
	 * Load library from xml files.
	 *
	 * @throws FileNotFoundException Signals that the requested file could not be found.
	 */
	public void loadLibrary() throws FileNotFoundException {
		XMLIO xmlrunner = new XMLIO();
		pizzas = (ArrayList<Pizza>) xmlrunner.decodeObject("libpizzas.xml");
		sides = (ArrayList<Side>) xmlrunner.decodeObject("libsides.xml");
		drinks = (ArrayList<Drink>) xmlrunner.decodeObject("libdrinks.xml");
	}
	
	/**
	 * Adds a new product to the library.
	 *
	 * @param product The product to be added.
	 */
	public void addProduct(Product product){
		getArrayList(product.getType()).add(product);
	}
	
	/**
	 * Find a product in the library and return it.
	 *
	 * @param name The name of the product
	 * @param type The type of the product
	 * @return The product (if found)
	 * @throws ProductNotFoundException Signals that the requested product could not be found.
	 */
	public Product findProduct(String name, ItemType type) throws ProductNotFoundException{
		ArrayList<Product> ps = getArrayList(type);
		for (Product p : ps){
			if(p.getDescription().equals(name)){
				return p;
			}
		}
		throw new ProductNotFoundException("Could not find the product: " + name);
	}
	
	/**
	 * Gets the list of pizzas.
	 *
	 * @return The list of pizzas
	 */
	public ArrayList<Pizza> getPizzas() {
		return pizzas;
	}
	
	/**
	 * Sets the list of pizzas.
	 *
	 * @param pizzas The new list of pizzas
	 */
	public void setPizzas(ArrayList<Pizza> pizzas) {
		this.pizzas = pizzas;
	}
	
	/**
	 * Gets the list of sides.
	 *
	 * @return The list of sides
	 */
	public ArrayList<Side> getSides() {
		return sides;
	}
	
	/**
	 * Sets the list of sides.
	 *
	 * @param sides The new list of sides
	 */
	public void setSides(ArrayList<Side> sides) {
		this.sides = sides;
	}
	
	/**
	 * Gets the list of drinks.
	 *
	 * @return The list of drinks
	 */
	public ArrayList<Drink> getDrinks() {
		return drinks;
	}
	
	/**
	 * Sets the list of drinks.
	 *
	 * @param drinks The new list of drinks
	 */
	public void setDrinks(ArrayList<Drink> drinks) {
		this.drinks = drinks;
	}

	/**
	 * Removes and item from the product library.
	 *
	 * @param item The item to be removed
	 */
	public void removeItem(Item item) {
		switch(item.getType()){
			case PIZZA:
				removeItem(pizzas, item);
				break;
			case SIDE:
				removeItem(sides, item);
				break;
			case DRINK:
				removeItem(drinks, item);
				break;
		}
	}
	
	private ArrayList<Product> getArrayList(ItemType type) {
		switch(type){
			case PIZZA:
				return (ArrayList) pizzas;
			case SIDE:
				return (ArrayList) sides;
			case DRINK:
				return (ArrayList) drinks;
			default:
				return null;
		}
	}
	
	private void removeItem(ArrayList<? extends Product> args, Item item){
		for (int i=0; i<args.size(); i++){
			if (args.get(i).equals(item)){
				args.remove(i);
			}
		}
	}
}
