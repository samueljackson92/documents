package uk.ac.aber.dcs.cs12420.aberpizza.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({ProductTest.class, SingleProductTest.class, TieredProductTest.class, OrderItemTest.class, OrderTest.class, 
	TillTest.class, ProductLibraryTest.class, MealDealDiscountTest.class,ThreeLargePizzasTest.class, XMLIOTest.class})

public class AllTests {}
