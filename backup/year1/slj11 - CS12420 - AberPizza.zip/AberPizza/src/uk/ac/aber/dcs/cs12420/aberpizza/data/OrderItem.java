package uk.ac.aber.dcs.cs12420.aberpizza.data;

import java.math.BigDecimal;

import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.TieredProduct;

/**
 * The Class OrderItem.
 * Stores information about both the item and 
 * the quantity of the item required in the order.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class OrderItem {
	
	/** The required quantity of the item. */
	private int quantity;
	
	/** The item. */
	private Item item;
	
	/**
	 * Instantiates a new order item.
	 */
	public OrderItem(){}
	
	/**
	 * Instantiates a new order item.
	 *
	 * @param item The item
	 * @param quantity The required quantity
	 */
	public OrderItem(Item item, int quantity) {
		setItem(item);
		setQuantity(quantity);
	}
	
	/**
	 * Gets the item.
	 *
	 * @return The item
	 */
	public Item getItem() {
		return item;
	}

	/**
	 * Sets the item.
	 *
	 * @param item The new item
	 */
	public void setItem(Item item) {
		this.item = item;
	}

	/**
	 * Gets the quantity.
	 *
	 * @return The quantity
	 */
	public int getQuantity() {
		return quantity;
	}
	
	/**
	 * Sets the quantity.
	 *
	 * @param quantity The new quantity
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	/**
	 * Gets the total price for this item.
	 *
	 * @return The total price
	 */
	public BigDecimal getOrderItemTotal(){
		return item.getPrice().multiply(new BigDecimal(getQuantity()));
	}
	
	/**
	 * Gets the description of the item, along with it's size and quantity.
	 *
	 * @return The description
	 */
	public String getDescription() {
		String output;
		output = item.getDescription();
		
		if(item instanceof TieredProduct) {
			output += " - Size: " + item.getSize();
		}
		
		output += " - Qty: " + getQuantity();
		
		return output; 
	}
}
