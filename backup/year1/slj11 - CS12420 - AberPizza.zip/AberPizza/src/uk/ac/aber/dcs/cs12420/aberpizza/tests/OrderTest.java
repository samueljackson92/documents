package uk.ac.aber.dcs.cs12420.aberpizza.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;
import uk.ac.aber.dcs.cs12420.aberpizza.data.OrderItem;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Drink;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Pizza;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Side;

public class OrderTest {

	private Order order;
	private ArrayList<OrderItem> items;

	@Before
	public void init(){
		order = new Order();
		items = new ArrayList<OrderItem>();
		
		Pizza p = new Pizza();
		p.setPrice(new BigDecimal(5));
		Side s = new Side();
		s.setPrice(new BigDecimal(5));
		Drink d = new Drink();
		d.setPrice(new BigDecimal(5));
		
		items.add(new OrderItem(p, 2));
		items.add(new OrderItem(s, 3));
		items.add(new OrderItem(d, 4));
	}

	@Test
	public void testModifyCustomerName(){
		order.setCustomerName("Bob");
		assertEquals("Should be equal", "Bob", order.getCustomerName());
	}

	@Test
	public void testModifyDate(){
		Date d = new Date();
		order.setDate(d);
		assertEquals("Should be equal", d, order.getDate());
	}

	@Test
	public void testGetReceipt(){
		order.setItems(items);
		order.setDate(new Date());
		assertNotNull("Should not be null", order.getReceipt());
	}

	@Test
	public void testToString(){
		assertNotNull("Should not be null", order.toString());
	}

	@Test
	public void testModifyItems(){		
		order.setItems(items);
		assertNotNull("Should not be null", order.getItems());
	}

	@Test
	public void testItemNotInOrder(){
		Pizza p = new Pizza();
		p.setSize(ItemSize.LARGE);
		p.setDescription("Cheese");
		
		order.setItems(items);
		assertFalse("Should be false", order.isInOrder(p));
	}
	
	@Test
	public void testItemIsInOrder(){
		Pizza p = new Pizza();
		p.setSize(ItemSize.LARGE);
		p.setDescription("Cheese");
		
		items.add(new OrderItem(p, 1));
		order.setItems(items);
		assertTrue("Should be true", order.isInOrder(p));
	}

	@Test
	public void testAddItem(){
		order.addItem(new Pizza(), 3);
		ArrayList<OrderItem> ois = order.getItems();
		
		assertTrue("Should be true", ois.size() == 1);
	}

	@Test
	public void testGetTotal(){
		Pizza p = new Pizza();
		p.setPrice(new BigDecimal(5));
		
		Side s = new Side();
		s.setPrice(new BigDecimal(2));
		
		order.addItem(p, 2);
		order.addItem(s, 1);
		
		assertTrue("Should be true", order.getTotal().intValue() == 12);
	}
	
	@Test
	public void testGetSubtotal(){
		Pizza p = new Pizza();
		p.setPrice(new BigDecimal(5));
		order.addItem(p, 3);
		assertTrue("Should be true", order.getTotal().intValue() == 15);
	}

	@Test
	public void testGetDiscount(){
		order.setItems(items);
		assertTrue("Should be true", order.getDiscount().equals(new BigDecimal("-5.00")));
	}

	@Test
	public void testRemoveItem(){
		order.setItems(items);
		order.removeItem(1);

		assertTrue("Should be true", order.getItems().get(0).getItem() instanceof Pizza 
				&& order.getItems().get(1).getItem() instanceof Drink);
	}
}
