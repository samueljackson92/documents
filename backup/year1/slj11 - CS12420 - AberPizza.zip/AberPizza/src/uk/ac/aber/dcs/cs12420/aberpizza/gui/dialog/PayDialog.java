package uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import uk.ac.aber.dcs.cs12420.aberpizza.gui.ErrorHandler;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.TillWindow;

/**
 * The Class PayDialog.
 * Takes payment for the cashiers who enters the amount that the customer spent
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
@SuppressWarnings("serial")
public class PayDialog extends AdminDialog implements ActionListener {

	/** The amount given by the customer. */
	private JTextField txtTendered;
	
	/**
	 * Instantiates a new pay dialogue.
	 *
	 * @param parent the parent window
	 * @param title the title of this dialogue
	 */
	public PayDialog(JFrame parent, String title) {
		super(parent, title);
		setLayout(new BorderLayout());
		
		JPanel panel = new JPanel();
		txtTendered  = new JTextField(4);
		
		panel.add(new JLabel("Amount Tendered:"));
		panel.add(txtTendered);
		
		add(panel, BorderLayout.NORTH);
		
		panel = new JPanel();
		JButton confirm = new JButton("Confirm Payment");
		confirm.addActionListener(this);
		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(this);
		panel.add(confirm);
		panel.add(cancel);
		
		add(panel, BorderLayout.CENTER);
		pack();
		setVisible(true);
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		
		if(command.equals("Confirm Payment")){
			try {
				BigDecimal tendered = new BigDecimal(txtTendered.getText());
				setVisible(false);
				((TillWindow) getParent()).confirmPayment(tendered);
				this.dispose();
			} catch (NumberFormatException ex){
				new ErrorHandler(getParent(), "Not numerical input!", ErrorHandler.INFO);
			}
		} else if (command.equals("Cancel")){
			this.dispose();
		}
	}

}
