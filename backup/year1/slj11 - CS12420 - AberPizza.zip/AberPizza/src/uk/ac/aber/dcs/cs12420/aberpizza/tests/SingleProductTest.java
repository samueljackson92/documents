package uk.ac.aber.dcs.cs12420.aberpizza.tests;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;

import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Side;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.SingleProduct;

public class SingleProductTest {

	@Test
	public void testModifyProductPrice(){
		SingleProduct side = new Side();
		side.setPrice(new BigDecimal(10));
		assertEquals("Should be equal", new BigDecimal(10), side.getPrice());;
	}
}
