package uk.ac.aber.dcs.cs12420.aberpizza.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import uk.ac.aber.dcs.cs12420.aberpizza.data.OrderItem;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Pizza;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Side;

public class OrderItemTest {
	
	private OrderItem orderItem;

	@Before
	public void init(){
		orderItem = new OrderItem(new Pizza(), 3);
	}
	
	@Test
	public void testModifyItem(){
		orderItem.setItem(new Side());
		assertTrue("Should be true", orderItem.getItem() instanceof Side);
	}
	
	@Test
	public void testModifyQuantity(){
		orderItem.setQuantity(5);
		assertTrue("Should be equal", orderItem.getQuantity() == 5);
	}

	@Test
	public void testGetTotalPrice(){
		Pizza p = new Pizza();
		p.setPrice(new BigDecimal(10));
		orderItem.setItem(p);
		
		assertEquals("Should be true", new BigDecimal(30), orderItem.getOrderItemTotal());
	}

	@Test
	public void testGetDescription(){
		assertNotNull("Should not be null", orderItem.getDescription());
	}
}
