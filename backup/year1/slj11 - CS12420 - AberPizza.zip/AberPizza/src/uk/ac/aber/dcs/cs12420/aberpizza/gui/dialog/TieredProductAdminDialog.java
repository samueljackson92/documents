package uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import uk.ac.aber.dcs.cs12420.aberpizza.data.model.TieredProduct;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.ErrorHandler;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.TillWindow;

// TODO: Auto-generated Javadoc
/**
 * The Class TieredProductAdminDialog.
 * Creates an admin dialog for adding or editing multi tiered products.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
@SuppressWarnings("serial")
public class TieredProductAdminDialog extends AdminDialog implements ActionListener {
	
	/** The fields for the description and prices. */
	private JTextField description, smallPrice, medPrice, largePrice;
	
	/** The selected product. */
	private TieredProduct selectedProduct;
	
	/**
	 * Instantiates a new tiered product admin dialog.
	 *
	 * @param parent The parent window
	 * @param product The selected product
	 */
	public TieredProductAdminDialog (TillWindow parent, TieredProduct product) {
		this(parent, product, false);
	}
	
	/**
	 * Instantiates a new tiered product admin dialog.
	 *
	 * @param parent The parent window
	 * @param product The selected product
	 * @param edit Whether we are adding or editing
	 */
	public TieredProductAdminDialog (TillWindow parent, TieredProduct product, boolean edit) {
	    super(parent, "Product Admin");
	    selectedProduct = product;
		
		JPanel content = new JPanel();
		content.setLayout(new BorderLayout());
		
		JPanel namePanel = new JPanel();
		namePanel.setBorder(new EmptyBorder(0,6,0,6));
		description = new JTextField(20);
		namePanel.add(new JLabel("Name: "));
		namePanel.add(description);
		
		JPanel pricesPanel = new JPanel();
		pricesPanel.setLayout(new GridLayout(3,2));
		pricesPanel.setBorder(new EmptyBorder(0,10,0,10));
		
		smallPrice = new JTextField(4);
		smallPrice.setText("0.00");
		medPrice = new JTextField(4);
		medPrice.setText("0.00");
		largePrice = new JTextField(4);
		largePrice.setText("0.00");
		
		pricesPanel.add(new JLabel("Small Price: "));
		pricesPanel.add(smallPrice);
		pricesPanel.add(new JLabel("Medium Price: "));
		pricesPanel.add(medPrice);
		pricesPanel.add(new JLabel("Large Price: "));
		pricesPanel.add(largePrice);
		
		JPanel buttons = new JPanel();
		JButton submit = new JButton("Add");
		submit.addActionListener(this);
		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(this);
		buttons.add(submit);
		buttons.add(cancel);
		
		content.add(namePanel, BorderLayout.NORTH);
		content.add(pricesPanel, BorderLayout.CENTER);
		content.add(buttons, BorderLayout.SOUTH);
		add(content);
		
		if (edit) {
			description.setText(product.getDescription());
			BigDecimal[] prices = product.getPrices();
			smallPrice.setText(prices[0].toPlainString());
			medPrice.setText(prices[1].toPlainString());
			largePrice.setText(prices[2].toPlainString());
			
			submit.setText("Edit");
			submit.setActionCommand("Edit");
		}
		
		pack();
	    
		setVisible(true);
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		
		if((command.equals("Add") || command.equals("Edit")) && validateForm()) {
			if(command.equals("Add")) {
				((TillWindow) getParent()).addProduct(selectedProduct);
			}
			modifyProduct();
		} else if(command.equals("Cancel")){
			this.dispose();
		}
	}
	
	/**
	 * Validate form.
	 *
	 * @return true, if successful
	 */
	private boolean validateForm(){
		if(!description.getText().isEmpty() && !smallPrice.getText().isEmpty()
				&& !medPrice.getText().isEmpty() && !largePrice.getText().isEmpty()) {
			try{
				BigDecimal small = new BigDecimal(smallPrice.getText());
				BigDecimal med = new BigDecimal(medPrice.getText());
				BigDecimal large = new BigDecimal(largePrice.getText());
				
				BigDecimal zero = new BigDecimal(0);
				if(small.compareTo(zero) > 0 && med.compareTo(zero) > 0 && large.compareTo(zero) > 0){
					return true;
				}
			} catch (NumberFormatException ex){
				new ErrorHandler(getParent(), "Not numerical input!", ErrorHandler.INFO);
			}
		}
		return false;
	}
	
	/**
	 * Modify product.
	 */
	private void modifyProduct() {
		TillWindow tw = (TillWindow) getParent();
		selectedProduct.setDescription(description.getText());
		selectedProduct.setPrices(convertPrices());
		tw.loadLibrary(selectedProduct.getType());
		this.dispose();
	}
	
	/**
	 * Convert prices.
	 *
	 * @return the big decimal[]
	 */
	private BigDecimal[] convertPrices() {
		return new BigDecimal[]{new BigDecimal(smallPrice.getText()), new BigDecimal(medPrice.getText()), new BigDecimal(largePrice.getText())};
	}
}
