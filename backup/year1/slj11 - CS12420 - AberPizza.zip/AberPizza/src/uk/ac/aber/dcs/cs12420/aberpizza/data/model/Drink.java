package uk.ac.aber.dcs.cs12420.aberpizza.data.model;

import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;

/**
 * The Class Drink.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class Drink extends SingleProduct {
	
	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Item#getType()
	 */
	@Override
	public ItemType getType() {
		return ItemType.DRINK;
	}
}
