package uk.ac.aber.dcs.cs12420.aberpizza.gui;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * The Class TillWindowListener
 * Listens to events from the window and acts accordingly
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class TillWindowListener extends WindowAdapter {

	/** The parent window. */
	private TillWindow parent;
	
	/**
	 * Instantiates a new till window listener.
	 *
	 * @param parent The parent window
	 */
	public TillWindowListener(TillWindow parent) {
		this.parent = parent;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.WindowAdapter#windowClosing(java.awt.event.WindowEvent)
	 */
	@Override
	public void windowClosing(WindowEvent e){
		parent.saveTill();
	}

}
