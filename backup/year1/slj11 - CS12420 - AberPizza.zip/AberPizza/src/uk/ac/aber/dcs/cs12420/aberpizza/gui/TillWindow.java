package uk.ac.aber.dcs.cs12420.aberpizza.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;
import uk.ac.aber.dcs.cs12420.aberpizza.data.OrderItem;
import uk.ac.aber.dcs.cs12420.aberpizza.data.ProductLibrary;
import uk.ac.aber.dcs.cs12420.aberpizza.data.Till;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;
import uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions.ItemNotSelectedException;
import uk.ac.aber.dcs.cs12420.aberpizza.data.exceptions.ProductNotFoundException;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Product;
import uk.ac.aber.dcs.cs12420.aberpizza.gui.dialog.ViewReciept;

/**
 * The Class TillWindow.
 * Creates the main window of the application.
 * All other windows are child dialogs of this window.
 * Events from this window are delegated to listener objects.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */

@SuppressWarnings("serial")
public class TillWindow extends JFrame{
	
	/** The menu bar listener for this window. */
	private MenuBarListener menubarListener;
	
	/** The the button listener for this window. */
	private ButtonListener buttonListener;
	
	/** The product library. */
	private ProductLibrary productLibrary;
	
	/** The till object. */
	private Till till;
	
	/** The current order being processed. */
	private Order currentOrder;
	
	/** What list the library is currently showing. */
	private ItemType libState = ItemType.PIZZA;

	/** The order items. */
	private DefaultListModel library, orderItems;
	
	/** The JLists for both the library and the current order. */
	private JList orderList, libList;
	
	/** The admin menu for adding/editing products. */
	private JMenu adminMenu;
	
	/** The popup menus for both lists. */
	private JPopupMenu libPopup, orderPopup;
	
	/** The subtotal and discount labels. */
	private JLabel subtotal, discounts;
	
	/** The field for the customers name. */
	private JTextField customerName;
	
	/** The different sizes of product available, if applicable */
	private JComboBox sizes;
	
	/**
	 * TillWindow constructor. Creates main application window.
	 * Also creates major window components and adds appropriate listeners
	 */
	public TillWindow () {
		super("AberPizza");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		
		this.addWindowListener(new TillWindowListener(this));
		
		Container contentPane =  getContentPane();
		GridLayout masterLayout = new GridLayout(1,2);
		masterLayout.setHgap(10);
		contentPane.setLayout(masterLayout);
		
		productLibrary = new ProductLibrary();
		
		menubarListener = new MenuBarListener(this);
		buttonListener = new ButtonListener(this);
		
		currentOrder = new Order();
		currentOrder.setDate(new Date());
		
		JMenu fileMenu = new JMenu("File");
		adminMenu = new JMenu("Admin");
		JMenu helpMenu = new JMenu("Help");
		
		//create the menu bar
		JMenuBar menuBar = new JMenuBar(); 
		setJMenuBar(menuBar);
		
		menuBar.add(fileMenu);
		menuBar.add(adminMenu);
		menuBar.add(helpMenu);
		 
		makeMenuItem("Open Till", fileMenu);
		makeMenuItem("Close Till", fileMenu);
		makeMenuItem("View Orders", fileMenu);
		makeMenuItem("View Today's Total", fileMenu);
		makeMenuItem("View Sales History", fileMenu);
		makeMenuItem("Exit", fileMenu);
		 
		JMenu subMenu = new JMenu("Add");
		makeMenuItem("Pizza", subMenu);
		makeMenuItem("Side", subMenu);
		makeMenuItem("Drink", subMenu);
		adminMenu.add(subMenu);
		
		makeMenuItem("Edit", adminMenu);
		makeMenuItem("Remove", adminMenu);
		 
		makeMenuItem("About", helpMenu);
	    
		 //create the left side panel
		JPanel leftSide = new JPanel();
		leftSide.setBorder(new EmptyBorder(10, 10, 10, 10));
		JPanel foodTypes = new JPanel();
		 
		//create the buttons for different types
		makeButton("Pizzas", foodTypes).setActionCommand(ItemType.PIZZA.toString());
		makeButton("Sides", foodTypes).setActionCommand(ItemType.SIDE.toString());
		makeButton("Drinks", foodTypes).setActionCommand(ItemType.DRINK.toString());
		 
		libList = new JList();
		library = new DefaultListModel();
		libList.setModel(library);
		libList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		 
		JPanel southRight = new JPanel();
		 
		makeButton("Add To Order", southRight);
		
		ItemSize[] items = ItemSize.values();
		sizes = new JComboBox(new ItemSize[]{items[0], items[1], items[2]});
		 
		southRight.add(new JLabel("Size: "));
		southRight.add(sizes);
		 
		leftSide.setLayout(new BorderLayout());
		leftSide.add(foodTypes, BorderLayout.NORTH);
		leftSide.add(new JScrollPane(libList), BorderLayout.CENTER);
		leftSide.add(southRight, BorderLayout.SOUTH);
		 
		//create the right side panel
		JPanel rightSide = new JPanel();
		rightSide.setBorder(new EmptyBorder(10, 10, 10, 10));
		JPanel customerNamePanel = new JPanel();
		 
		JLabel orderFor = new JLabel("Order For: ");
		customerName = new JTextField(20);
		 
		customerNamePanel.add(orderFor);
		customerNamePanel.add(customerName);
		 
		orderItems = new DefaultListModel();
		orderList = new JList();
		orderList.setModel(orderItems);
		orderList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		 
		JPanel totals = new JPanel();
		discounts = new JLabel();
		subtotal = new JLabel();
		
		discounts.setText("Discount: �" + currentOrder.getDiscount().abs());
		subtotal.setText("Subtotal: �" + currentOrder.getTotal());
		 
		totals.add(discounts);
		totals.add(subtotal);
		 
		JPanel finishButtons = new JPanel();
		makeButton("Pay", finishButtons);
		makeButton("Cancel", finishButtons);
		 
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new BorderLayout());
		bottomPanel.add(totals, BorderLayout.NORTH);
		bottomPanel.add(finishButtons, BorderLayout.CENTER);
		 
		rightSide.setLayout(new BorderLayout());
		rightSide.add(customerNamePanel, BorderLayout.NORTH);
		rightSide.add(new JScrollPane(orderList), BorderLayout.CENTER);
		rightSide.add(bottomPanel, BorderLayout.SOUTH);
		 
		
		libPopup = new JPopupMenu();
		orderPopup = new JPopupMenu();
		MouseListener popupListener = new PopupListener(libPopup);
		libList.addMouseListener(popupListener);
		popupListener = new PopupListener(orderPopup);
		orderList.addMouseListener(popupListener);
		
	    JMenuItem edit = new JMenuItem("Edit");
	    JMenuItem remove = new JMenuItem("Remove");
	    edit.addActionListener(menubarListener);
	    remove.addActionListener(menubarListener);
	    libPopup.add(edit);
	    libPopup.add(remove);
	    
	    remove = new JMenuItem("Remove From Order");
	    remove.addActionListener(menubarListener);
	    edit = new JMenuItem("Edit Quantity");
	    edit.addActionListener(menubarListener);
	    orderPopup.add(edit);
	    orderPopup.add(remove);

		add(leftSide);
		add(rightSide);
		pack();
		 
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		
		int w = getSize().width;
		int h = getSize().height;
		int x = (dim.width-w)/2;
		int y = (dim.height-h)/2;

		setLocation(x, y);

		loadTill();
		loadLibrary(libState);
		setVisible(true);
	}
	
	private void makeMenuItem(String name, JMenu menu) {
		JMenuItem menuItem = new JMenuItem(name);
		menuItem.addActionListener(menubarListener);
		menu.add(menuItem);
	}
	
	private JButton makeButton(String name, JPanel panel) {
		JButton button = new JButton(name);
		button.addActionListener(buttonListener);
		panel.add(button);
		return button;
	}
	
	/**
	 * Gets the till object.
	 *
	 * @return the till object
	 */
	public Till getTill() {
		return till;
	}
	
	/**
	 * Adds the order to the till.
	 *
	 * @param order The order
	 */
	public void addOrder(Order order) {
		till.addOrder(order);
	}
	
	/**
	 * Adds a product to the order currently being processed.
	 *
	 * @param product The product
	 */
	public void addToOrder(Product product) {
		Product newItem = product.copy();
		
		if (!currentOrder.isInOrder(newItem)){
			currentOrder.addItem(newItem, 1);
		} else {
			for (OrderItem oi : currentOrder.getItems()) {
				if(oi.getItem().equals(product)){
					currentOrder.updateItemQuantity(oi.getItem(), oi.getQuantity()+1);
				}
			}
		}
		
		loadOrder();
	}
	
	/**
	 * Gets what item type the library is currently showing.
	 *
	 * @return The library's current state
	 */
	public ItemType getLibraryState() {
		return libState;
	}

	/**
	 * Sets the item type the library is currently showing.
	 *
	 * @param libState the new library state
	 */
	public void setLibState(ItemType libState) {
		this.libState = libState;
	}

	/**
	 * Sets the size drop down to specified boolean state.
	 *
	 * @param enable the new boolean state
	 */
	public void setSizeOptionEnabled(boolean enable) {
		sizes.setEnabled(enable);
	}
	
	/**
	 * Clear the current order.
	 */
	public void clearOrder() {
		customerName.setText("");
		currentOrder = new Order();
		loadOrder();
	}
	
	/**
	 * Load a list of products from the product library.
	 *
	 * @param type The of the items to be loaded
	 */
	public void loadLibrary(ItemType type) {
		library.removeAllElements();
		setLibState(type);
		
		ArrayList<? extends Product> products = null;
		
		switch(type) {
			case PIZZA:
				products = productLibrary.getPizzas();
				break;
			case SIDE:
				products = productLibrary.getSides();
				break;
			case DRINK:
				products = productLibrary.getDrinks();
				break;
		}
		
		if(products != null){
			for (Product product : products) {
				library.addElement(product.getDescription());
			}
		} else {
			new ErrorHandler(this, "Internal Casting Error!", ErrorHandler.ERROR);
		}
	}
	
	/**
	 * Adds a product to the product library.
	 *
	 * @param product The product to be added.
	 */
	public void addProduct(Product product) {
		productLibrary.addProduct(product);
		loadLibrary(product.getType());
	}

	/**
	 * Gets the selected library item.
	 *
	 * @return the selected library item
	 * @throws ItemNotSelectedException Signals that no item was selected.
	 * @throws ProductNotFoundException Signals that the product could not be found.
	 */
	public Product getSelectedLibraryItem() throws ItemNotSelectedException, ProductNotFoundException {
		if(libList.getSelectedIndex()>=0) {
			String name = (String) library.get(libList.getSelectedIndex());
			return productLibrary.findProduct(name, getLibraryState());
		} else {
			throw new ItemNotSelectedException("No item has been selected yet!\nPlease select an item.");
		}
	}
	
	/**
	 * Save and close the till for the day.
	 */
	public void saveTill(){
		try {
			productLibrary.saveLibrary();
			till.save();
			enableComponentTree(getContentPane(), false);
			enableComponentTree(adminMenu, false);
			enableComponentTree(libPopup, false);
			enableComponentTree(orderPopup, false);
		} catch (IOException ex) {
			new ErrorHandler(this, ex, ErrorHandler.ERROR);
		}
	}

	/**
	 * Load till for the day.
	 */
	public void loadTill() {
		try {
			productLibrary.loadLibrary();
			till = Till.load();
			enableComponentTree(getContentPane(), true);
			enableComponentTree(adminMenu, true);
			enableComponentTree(libPopup, true);
			enableComponentTree(orderPopup, true);
		} catch (IOException ex) {
			new ErrorHandler(this, ex, ErrorHandler.ERROR);
		}
	}

	/**
	 * Gets the selected item size.
	 *
	 * @return The selected size
	 */
	public ItemSize getSelectedSize() {
		return (ItemSize) sizes.getSelectedItem();
	}
	
	/**
	 * Load the current order into the JList orders box.
	 */
	public void loadOrder() {
		orderItems.clear();
		for (OrderItem i : currentOrder.getItems()){
			orderItems.addElement(i.getDescription());
		}
		
		discounts.setText("Discount: �" + currentOrder.getDiscount().abs());
		subtotal.setText("Subtotal: �" + currentOrder.getTotal());
	}

	/**
	 * Finish transaction, and prepare it for another.
	 */
	private void finishTransaction() {
		till.addOrder(currentOrder);
		new ViewReciept(this, "Reciept", currentOrder);
		clearOrder();
	}
	
	/**
	 * Confirm that the payment is valid
	 * @param tendered The amount of money given by the customer.
	 */
	public void confirmPayment(BigDecimal tendered){
		if(tendered.compareTo(currentOrder.getTotal()) >= 0){
			finishTransaction();
		} else {
			new ErrorHandler(this, "Payment is invalid\n Not enough cash!", ErrorHandler.INFO);
		}
	}
	
	/**
	 * Enable or disable a tree of components.
	 *
	 * @param root The root components
	 * @param enable The desired boolean state
	 */
	private void enableComponentTree(Container root, boolean enable){
		Component[] children = root.getComponents();
		root.setEnabled(enable);
		if (children.length > 0){
			for (Component c : children){
				if(c instanceof Container){
					enableComponentTree((Container)c, enable);
				}
				c.setEnabled(enable);
			}
		}
	}

	/**
	 * Removes a selected library item.
	 */
	public void removeLibraryItem() {
		Product p = null;
		try {
			p = getSelectedLibraryItem();
		} catch (ItemNotSelectedException e) {
			new ErrorHandler(this, e, ErrorHandler.INFO);
			return;
		} catch (ProductNotFoundException e) {
			new ErrorHandler(this, e, ErrorHandler.ERROR);
			return;
		}
		
		productLibrary.removeItem(p);
		loadLibrary(p.getType());
	}

	/**
	 * Removes a selected order item.
	 */
	public void removeOrderItem() {
		if(orderList.getSelectedIndex() >= 0){
			currentOrder.removeItem(orderList.getSelectedIndex());
			loadOrder();
		} else {
			new ErrorHandler(this, "No item has been selected yet!\nPlease select an item.", ErrorHandler.INFO);
		}
	}

	public String getDailyTotal() {
		return till.getTotalForTheDay().toString();
	}

	/**
	 * Update the quantity of an item in the order
	 * @param amount The desired amount of the product
	 */
	public void updateItem(int amount) {
		
			if(orderList.getSelectedIndex() >= 0){
				if(amount >= 1) {
					currentOrder.updateItemQuantity(currentOrder.getItems().get(orderList.getSelectedIndex()).getItem(), amount);
					loadOrder();
				} else {
					removeOrderItem();
				}
			} else {
				new ErrorHandler(this, "No item has been selected yet!\nPlease select an item.", ErrorHandler.INFO);
			}

	}

	/**
	 * Check that the order is valid before processing payment
	 * @return boolean for if the order is valid or not
	 */
	public boolean validateOrder() {
		if(!customerName.getText().isEmpty()){
			if(!currentOrder.getItems().isEmpty()){
				
				//then order is valid
				currentOrder.setCustomerName(customerName.getText());
				currentOrder.setDate(new Date());
				
				return true;
			} else {
				new ErrorHandler(this, "No Products in order!", ErrorHandler.INFO);
			}
		} else {
			new ErrorHandler(this, "Please enter a name for the customer.", ErrorHandler.INFO);
		}
		
		return false;
	}
}
