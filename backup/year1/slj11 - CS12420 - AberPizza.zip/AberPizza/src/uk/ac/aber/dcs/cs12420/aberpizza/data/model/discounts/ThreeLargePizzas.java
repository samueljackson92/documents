/*
 * 
 */
package uk.ac.aber.dcs.cs12420.aberpizza.data.model.discounts;

import java.math.BigDecimal;

import uk.ac.aber.dcs.cs12420.aberpizza.data.Order;
import uk.ac.aber.dcs.cs12420.aberpizza.data.OrderItem;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemSize;
import uk.ac.aber.dcs.cs12420.aberpizza.data.enums.ItemType;
import uk.ac.aber.dcs.cs12420.aberpizza.data.model.Discount;

// TODO: Auto-generated Javadoc
/**
 * The Class ThreeLargePizzas.
 * A discount which gives the customer �7 off if they buy 3 large pizzas.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 */
public class ThreeLargePizzas extends Discount {
	
	/**
	 * Instantiates a new three large pizzas.
	 */
	public ThreeLargePizzas() {
		setDescription("�5 off three large pizzas");
		setPrice(new BigDecimal("-7.00"));
	}

	/* (non-Javadoc)
	 * @see uk.ac.aber.dcs.cs12420.aberpizza.data.model.Discount#calculate(uk.ac.aber.dcs.cs12420.aberpizza.data.Order)
	 */
	@Override
	public BigDecimal calculate(Order order) {
		int itemCount = 0;
		for(OrderItem i : order.getItems()){
			if (i.getItem().getSize() == ItemSize.LARGE && i.getItem().getType() == ItemType.PIZZA) {
				itemCount += i.getQuantity();
	
				if(itemCount >= 3) {
					return getPrice();
				}
			}
		}
		return new BigDecimal(0);
	}

}
