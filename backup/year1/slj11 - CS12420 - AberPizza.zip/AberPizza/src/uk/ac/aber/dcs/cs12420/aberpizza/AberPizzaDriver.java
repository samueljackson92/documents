package uk.ac.aber.dcs.cs12420.aberpizza;

import uk.ac.aber.dcs.cs12420.aberpizza.gui.TillWindow;

/**
 * Driver for the whole application.
 * Simply creates a new instance of TillWindow to start the GUI.
 * 
 * @author Samuel Jackson (slj11@aber.ac.uk)
 * 
 */
public class AberPizzaDriver {

	/**
	 * The main method for the project, launches an instance of the TillWindow class.
	 *
	 * @param args The arguments passed from the command line (currently not used).
	 */
	public static void main(String[] args) {
		new TillWindow();
	}
}
